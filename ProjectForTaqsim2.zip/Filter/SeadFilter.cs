﻿namespace ProjectForTaqsim.Filter;

public class SeadFilter
{
    public long? FromRow { get; set; }
    public long? ToRow { get; set; }
}
